package com.example.employeedb;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = Employee_Entity.class, exportSchema = false, version = 2)
public abstract  class Employee_Database extends RoomDatabase {

    private static final  String Room_db = "EMPLOYEE_DATABASE";
    private static Employee_Database instance;

    public static  synchronized Employee_Database getDB(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context, Employee_Database.class, Room_db)
                    .fallbackToDestructiveMigration()
                    .allowMainThreadQueries()
                    .build();
        }
        return  instance;
    }
    public  abstract  Employee_Dao employee_dao();
}





