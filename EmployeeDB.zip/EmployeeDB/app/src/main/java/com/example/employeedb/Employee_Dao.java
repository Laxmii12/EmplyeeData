package com.example.employeedb;


import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;
@Dao
public interface  Employee_Dao {

    @Query("select * from Employee_Table")
    abstract List<Employee_Entity> getAllEmployeeData() ;

    @Insert
    abstract void addData(Employee_Entity Employee_Table);

    @Update
    abstract void updateData(Employee_Entity employee_entity);


    @Delete
    abstract void DeleteData(Employee_Entity employee_entity);

    @Query("DELETE FROM Employee_Table where id = :id")
    abstract void DeleteData1(int id);

}
