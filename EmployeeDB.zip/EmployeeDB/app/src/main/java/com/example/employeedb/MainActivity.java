package com.example.employeedb;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    EditText e_name;
    EditText e_id;
    EditText e_salary;
    EditText e_expenditure;
    Button submit_btn;
    Button update_btn;
    Button delete_btn;
    Button fetch_btn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e_name = findViewById(R.id.e_name);
        e_id = findViewById(R.id.E_id);
        e_salary = findViewById(R.id.E_salary);
        e_expenditure = findViewById(R.id.E_expenditure);
        submit_btn = findViewById(R.id.submit_button);
        update_btn = findViewById(R.id.update_button);

        delete_btn = findViewById(R.id.Delete_button);
        fetch_btn = findViewById(R.id.fetch_button);


//        -----------------------------------------------

        Employee_Database employee_database = Employee_Database.getDB(this);


        fetch_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ArrayList<Employee_Entity> listOfEmployee = (ArrayList<Employee_Entity>) employee_database.employee_dao().getAllEmployeeData();
                for (int i = 0; i < listOfEmployee.size(); i++) {
                    Log.d("------------>" + "data", "ID:" + listOfEmployee.get(i).getId() + "   Name: " + listOfEmployee.get(i).getName() + "   salary: " + listOfEmployee.get(i).getSalary() +
                            "   expenditure: " + listOfEmployee.get(i).getExpenditure());
                }

            }
        });

        delete_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int id = Integer.parseInt(e_id.getText().toString());
                Employee_Entity employee_entity = new Employee_Entity();
                employee_entity.setId(id);
                employee_database.employee_dao().DeleteData1(id);
                ArrayList<Employee_Entity> listOfEmployee = (ArrayList<Employee_Entity>) employee_database.employee_dao().getAllEmployeeData();
                for (int i = 0; i < listOfEmployee.size(); i++) {
                    Log.d("------------>" + "data", "   ID:" + listOfEmployee.get(i).getId() + "   Name: " + listOfEmployee.get(i).getName() + "   salary: " + listOfEmployee.get(i).getSalary() +
                            "   expenditure: " + listOfEmployee.get(i).getExpenditure());
                }

            }
        });


        submit_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String id = e_id.getText().toString();
                String name = e_name.getText().toString();
                String salry = e_salary.getText().toString();
                String expenditure = e_expenditure.getText().toString();
                employee_database.employee_dao().addData(
                        new Employee_Entity(Integer.parseInt(id), name, salry, expenditure)
                );
                ArrayList<Employee_Entity> listOfEmployee = (ArrayList<Employee_Entity>) employee_database.employee_dao().getAllEmployeeData();

                for (int i = 0; i < listOfEmployee.size(); i++) {
//                        int no = listOfEmployee.size();
//                        Log.d("ddd", String.valueOf(+no));
                    Log.d("------------>" + "data", "ID:  " + listOfEmployee.get(i).getId() + "   Name:  " + listOfEmployee.get(i).getName() + "   salary: " + listOfEmployee.get(i).getSalary() +
                            "    expenditure:   " + listOfEmployee.get(i).getExpenditure());
                }
            }

            ;
        });

        update_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int id = Integer.parseInt(e_id.getText().toString());
                String name = e_name.getText().toString();
                String salry = e_salary.getText().toString();
                String expenditure = e_expenditure.getText().toString();
                Employee_Entity employee_entity = new Employee_Entity();
                employee_entity.setId(id);
                employee_entity.setName(name);
                employee_entity.setSalary(salry);
                employee_entity.setExpenditure(expenditure);
                employee_database.employee_dao().updateData(employee_entity);
                ArrayList<Employee_Entity> listOfEmployee = (ArrayList<Employee_Entity>) employee_database.employee_dao().getAllEmployeeData();
                for (int i = 0; i < listOfEmployee.size(); i++) {
                    Log.d("------------>" + "data", "   ID:   " + listOfEmployee.get(i).getId() + "   Name:   " + listOfEmployee.get(i).getName() + "    salary:   " + listOfEmployee.get(i).getSalary() +
                            "   expenditure:  " + listOfEmployee.get(i).getExpenditure());
                }
            }
        });
    }
}