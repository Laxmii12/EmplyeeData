package com.example.employeedb;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "Employee_Table")
public class Employee_Entity {
    @PrimaryKey()
    private int id;
    @ColumnInfo(name =  "Ename")
    private String name;
    @ColumnInfo(name =  "Esalary")
    private String   salary;
    @ColumnInfo(name =  "Eexpenditure")
    private String expenditure;


    Employee_Entity(int id,  String name,String salary, String expenditure ){
        this.id = id;
        this.name = name;
        this.salary = salary;
        this.expenditure = expenditure;
    }

    Employee_Entity() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSalary() {
        return salary;
    }

    public void setSalary(String salary) {
        this.salary = salary;
    }

    public String getExpenditure() {
        return expenditure;
    }

    public void setExpenditure(String expenditure) {
        this.expenditure = expenditure;
    }
}
